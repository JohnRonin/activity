Let menu = document.querySelector("#menu_icon");
Let nav = document.querySelector(".navbar");
			
menu.onclick = () =>{
	menu.classList.toggle("bx-x"),
	nav.classList.toggle("open"),
	
};